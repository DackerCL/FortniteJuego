package puppy.code;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.TimeUtils;

public class Lluvia {
    private Array<Rectangle> rainDropsPos;
    private Array<Integer> rainDropsType;
    private long lastDropTime;
    private Texture gotaBuena;
    private Texture gotaMala;
    private Texture gotaEspecial;
    private Texture gotaBuenaNueva; // Nueva textura para gotas buenas a partir de 1000 puntos
    private Texture gotaEspecialNueva; // Nueva textura para gotas especiales a partir de 1000 puntos
    private Sound dropSound;
    private Music rainMusic;
    private boolean texturasCambiadas = false; // Control para el cambio de texturas
    
    // Variables de velocidad y tiempo de generación
    private float velocidadCaidaInicial = 150; // Velocidad reducida
    private float velocidadCaidaActual = velocidadCaidaInicial;
    private float velocidadCaidaOriginal = 300; // Velocidad original para cuando el jugador llegue a 1000 puntos
    private long intervaloGeneracionInicial = 150000000; // Intervalo inicial más amplio entre gotas (150 ms)
    private long intervaloGeneracionActual = intervaloGeneracionInicial;
    private long intervaloGeneracionOriginal = 100000000; // Intervalo original más rápido entre gotas (100 ms)
	   
    public Lluvia(Texture gotaBuena, Texture gotaMala, Texture gotaEspecial, Texture gotaBuenaNueva, Texture gotaEspecialNueva, Sound dropSound, Music rainMusic) {
        this.rainMusic = rainMusic;
        this.dropSound = dropSound;
        this.gotaBuena = gotaBuena;
        this.gotaMala = gotaMala;
        this.gotaEspecial = gotaEspecial;
        this.gotaBuenaNueva = gotaBuenaNueva;
        this.gotaEspecialNueva = gotaEspecialNueva;
        
        // Establecer el volumen de la música al 40%
        this.rainMusic.setVolume(0.4f); // 0.4f representa el 40% del volumen máximo
    }
    
    public void crear() {
        rainDropsPos = new Array<Rectangle>();
        rainDropsType = new Array<Integer>();
        crearGotaDeLluvia();
        rainMusic.setLooping(true);
        rainMusic.play();
    }
    
    // Método para cambiar la textura de la gota mala
    public void cambiarGotaMala(Texture nuevaGotaMala) {
        this.gotaMala.dispose(); // Liberar la textura anterior
        this.gotaMala = nuevaGotaMala; // Asignar la nueva textura
    }

    private void crearGotaDeLluvia() {
        Rectangle raindrop = new Rectangle();
        raindrop.x = MathUtils.random(0, 800 - 64);
        raindrop.y = 480;

        // Determinar el tipo de gota y ajustar la hitbox si es necesario
        int tipoGota = MathUtils.random(1, 100);
        
        if (tipoGota <= 45) { // 45% de probabilidad para gotas buenas (normales)
            rainDropsType.add(2); // Gota buena
            raindrop.width = 64; // Tamaño estándar
            raindrop.height = 64;
        } else if (tipoGota <= 85) { // 40% de probabilidad para gotas malas
            rainDropsType.add(1); // Gota mala
            raindrop.width = 64 * 0.8f; // 80% del tamaño estándar en ancho
            raindrop.height = 64 * 0.8f; // 80% del tamaño estándar en altura
        } else { // 4% de probabilidad para gotas especiales
            rainDropsType.add(3); // Gota especial
            raindrop.width = 64; // Tamaño estándar
            raindrop.height = 64;
        }

        rainDropsPos.add(raindrop);
        lastDropTime = TimeUtils.nanoTime();
    }
    
    public boolean actualizarMovimiento(Tarro tarro) { 
        // Verificar y actualizar la velocidad, intervalo de generación y cambio de texturas cuando el puntaje es 1000 o más
        if (tarro.getPuntos() >= 1000) {
            velocidadCaidaActual = velocidadCaidaOriginal;
            intervaloGeneracionActual = intervaloGeneracionOriginal;
            
            // Cambiar texturas de gotas buenas y especiales si aún no se han cambiado
            if (!texturasCambiadas) {
                gotaBuena.dispose();
                gotaEspecial.dispose();
                gotaBuena = gotaBuenaNueva;
                gotaEspecial = gotaEspecialNueva;
                texturasCambiadas = true; // Marcar que ya se han cambiado las texturas
            }
        }

        // Generar nuevas gotas de lluvia en función del intervalo de generación actual
        if (TimeUtils.nanoTime() - lastDropTime > intervaloGeneracionActual) {
            crearGotaDeLluvia();
        }

        // Verificar si las gotas cayeron o chocaron con el tarro
        for (int i = 0; i < rainDropsPos.size; i++) {
            Rectangle raindrop = rainDropsPos.get(i);
            raindrop.y -= velocidadCaidaActual * Gdx.graphics.getDeltaTime();
            
            // Si cae al suelo, eliminarla
            if (raindrop.y + raindrop.height < 0) {
                rainDropsPos.removeIndex(i);
                rainDropsType.removeIndex(i);
                continue;
            }

            // Verificar colisión con el tarro
            if (raindrop.overlaps(tarro.getArea())) {
                int tipoGota = rainDropsType.get(i);
                switch (tipoGota) {
                    case 1: // Gota mala
                        tarro.dañar();
                        if (tarro.getVidas() <= 0) return false; // Game over si se queda sin vidas
                        break;
                    case 2: // Gota buena
                        tarro.sumarPuntos(10);
                        dropSound.play(0.4f); // Volumen del 40% para el efecto de sonido
                        break;
                    case 3: // Gota especial
                        tarro.sumarPuntos(50); // Gota especial otorga más puntos
                        dropSound.play(0.4f); // Volumen del 40% para el efecto de sonido
                        break;
                }
                rainDropsPos.removeIndex(i);
                rainDropsType.removeIndex(i);
            }
        } 
        return true; 
    }
   
    public void actualizarDibujoLluvia(SpriteBatch batch) { 
        for (int i = 0; i < rainDropsPos.size; i++) {
            Rectangle raindrop = rainDropsPos.get(i);
            int tipoGota = rainDropsType.get(i);
            
            // Dibujar las gotas según su tipo
            if (tipoGota == 1) {
                batch.draw(gotaMala, raindrop.x, raindrop.y);
            } else if (tipoGota == 2) {
                batch.draw(gotaBuena, raindrop.x, raindrop.y);
            } else if (tipoGota == 3) {
                batch.draw(gotaEspecial, raindrop.x, raindrop.y);
            }
        }
    }

    // Método para liberar los recursos de sonido y música
    public void destruir() {
        dropSound.dispose();
        rainMusic.dispose();
        gotaBuena.dispose();
        gotaMala.dispose();
        gotaEspecial.dispose();
        gotaBuenaNueva.dispose();
        gotaEspecialNueva.dispose();
    }

    // Método para pausar la música
    public void pausar() {
        if (rainMusic.isPlaying()) {
            rainMusic.pause();
        }
    }

    // Método para continuar la música desde donde se pausó
    public void continuar() {
        if (!rainMusic.isPlaying()) {
            rainMusic.play();
        }
    }
}
